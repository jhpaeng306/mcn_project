V1 LaTeX reports

Compile each .tex file with pdflatex twice, or latexmk -pdf.
Keep figures/ beside the .tex files. Standard TeX Live packages are used.
The reports refer to the project's executed notebook and numerical records;
the full-precision nominal coefficients are included as calibration.json.
Report 1: sources, assumptions and gain calibration (3 pages).
Report 2: explicit mathematics, locally certified increase and 2D analysis (11 pages).
